const Home = () => {
    return (
        <div class="align-middle">
            <div class="row">
                <div class="row">
                    <div class="row">
                        <div className="home">
                            <h2>Home Page</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>

     );
}

export default Home;
